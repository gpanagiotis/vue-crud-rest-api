<template>
    <div>
        <h1>Page 3</h1>
        <p>Stored value is {{stored}}</p>
    </div>
</template>

<script>
    export default {
        name: "Page3",
        props: {
            stored: Number,
        }
    }
</script>

<style scoped>

</style>
